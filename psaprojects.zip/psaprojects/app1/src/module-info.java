/**
 * 
 */
/**
 * @author core360
 *
 */
module app1 {
}