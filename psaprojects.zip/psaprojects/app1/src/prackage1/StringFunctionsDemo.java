package prackage1;

import java.util.Scanner;

public class StringFunctionsDemo {
	
	
	public void stringmanipulation() {
		
		System.out.print("Enter a String:");
		Scanner scan1 = new Scanner(System.in);
		String mystring = scan1.nextLine();
		scan1.close();
		
		System.out.println("Characters: " + mystring.length());
		System.out.println("Uppercase: " + mystring.toUpperCase());
		System.out.println("Lowercase: " + mystring.toLowerCase());
		System.out.println("First 3 chars: " + mystring.substring(0, 3));
		System.out.println("Last 3 chars: " 
		+ mystring.substring(mystring.length()-3, mystring.length()));
		
		System.out.println("Replace a with e: " + mystring.replace("a", "e"));
		System.out.println("Contains spaces?: " + mystring.contains(" "));
		
		
		
		
		
	}
	
	

}
