package prackage1;

public class Buildings {

//	public static void main(String[] args) {
//		
//		// create a new instance of the class
//		Building1 b1 = new Building1();
//		String n = b1.name;
//		String c = b1.contactnumber;
//		int s = b1.storeys;
//		System.out.println(n + " " + c + " " + s);
//		b1.greetme();
//		b1.greetmyname("henry","fonnie");
//		
//		
//		Building2 b2 = new Building2();
//		String n2 = b2.name;
//		String c2 = b2.contactnumber;
//		System.out.println(n2 + " " + c2);
//		b2.greetme();
//	
//	}

}
