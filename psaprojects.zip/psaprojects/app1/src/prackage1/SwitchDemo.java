package prackage1;

import java.util.Scanner;

public class SwitchDemo {
	
	
	public void getequivalent() {
		
		// Custom Greeting
		// Name: Mariel
		// Gender: Female / Male
		// Civil Status: Single / Married
		// Hi Miss Mariel!
		Scanner scan1 = new Scanner(System.in);
		System.out.print("Enter name: ");
		String n = scan1.nextLine();
		System.out.print("Enter gender (male/female): ");
		String g = scan1.next();
		System.out.print("Enter civil status (single/married): ");
		String c = scan1.next();
		scan1.close();
		
		//title variable
		String t = "";
		
		switch(g) {
		case "male":
			t = "Mr.";
			break;
		
		case "female":
			if(c.equals("single")) { 
				t = "Miss ";
				break;
			}else if(c.equals("married")){ 
				t = "Mrs."; 
				break;
			}else {
				t = ""; 
				break;
				
			}
			

		default:
			t = "";
			break;
		}
		
		System.out.println("Hi " + t + n);
		
		
	}
	

}
