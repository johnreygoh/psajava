package prackage1;

import java.util.Scanner;

public class Activity1 {
	
	public void productpricecalculator() {
		System.out.println("-----------------------------------");
		System.out.println("-----Product Price Calculator------");
		System.out.println("-----------------------------------");
		
//		legend: a:100,b:200,c:300,addon:50
//		*note: discount applies to gross total
		
		//get user input
		Scanner scan1 = new Scanner(System.in);
		System.out.print("Product [a/b/c]:");
		String p = scan1.next();

		System.out.print("Addon [y/n]:");
		String a = scan1.next();

		System.out.print("Quantity:");
		int q = scan1.nextInt();

		System.out.print("5% Discount [y/n]:");
		String d = scan1.next();

		//create variable for prices
		float pprice = 0;
		float aprice = 0;
		double discount = 0;
		double netprice = 0;
					
		//define product price
		switch(p) {
		case "a": pprice=100;break;
		case "b": pprice=200;break;
		case "c": pprice=300;break;
		default: pprice=0;break;
		}
		
		//define addon price
		switch(a) {
		case "y": aprice=50;break;
		default: aprice=0;break;
		}
		
		//get gross total
		float gt = (pprice + aprice) * q;
		
		//get discount
		switch(d) {
		case "y": discount= gt * 0.05 ; break;
		default: discount=0;break;
		}
		
		//get net total
		netprice = gt - discount;
		
		System.out.println("Total: PHP" + netprice);
		
	}
	
	

}
