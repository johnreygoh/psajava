package prackage1;

public class Class1 {

//	public static void main(String[] args) {
//		System.out.println("Hello PSA");
//		//call myname method
//		myname();
//		mycompany();
//		System.out.println(mylastname());
//		
//	}
	
	public static void myname() {
		System.out.println("Hi John!");
	}
	
	public static void mycompany() {
		System.out.println("I work at PSA!");	
	}
	
	public static String mylastname() {
		System.out.println(myfullname());
		return "Reyes"; //exit method
	}
	
	public static String myfullname() {
		return "john doe";
	}
	

}
