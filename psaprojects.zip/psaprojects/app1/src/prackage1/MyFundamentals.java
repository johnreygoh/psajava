package prackage1;

import java.util.Scanner;

public class MyFundamentals {

	public static void main(String[] args) {
		
//		DataTypesDemo datatypesdemo = new DataTypesDemo();
//		datatypesdemo.testinput();

		System.out.println("\n\n------------------");
		System.out.println("Java Fundamentals Demo");
		System.out.println("------------------\n\n");
		
		//data types demo
//		DataTypesDemo dtd = new DataTypesDemo();
//		Scanner scanner1 = new Scanner(System.in);
//		System.out.print("Enter a byte: ");
//		byte b = scanner1.nextByte();
//		System.out.print("Enter a short: ");
//		short s = scanner1.nextShort();
//		System.out.print("Enter a int: ");
//		int i = scanner1.nextInt();
//		System.out.print("Enter a String: ");
//		String st = scanner1.next();
//		System.out.print("Enter a boolean: ");
//		boolean bo = scanner1.nextBoolean();
//		
//		dtd.provideInput(b, s, i, st, bo);
//		scanner1.close();
		
//		ConvertTypesDemo ctd = new ConvertTypesDemo();
//		ctd.getsum();

//		StringFunctionsDemo sfd = new StringFunctionsDemo();
//		sfd.stringmanipulation();

//		DateDemo dd = new DateDemo();
//		dd.showdate();

//		IfDemo ifdemo = new IfDemo();
//		ifdemo.readytovote();

//		SwitchDemo sd = new SwitchDemo();
//		sd.getequivalent();
		
		Activity1 activity1 = new Activity1();
		activity1.productpricecalculator();
				
		
		
	}

}
