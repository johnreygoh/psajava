package prackage1;

public class Building2 {
	
	//properties
	String name = "TAM";
	private int storeys = 5;
	String contactnumber = "8887766";
	
	public void greetme() {
		System.out.println("Hi Guest!");
	}
	

}
