package prackage1;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo {
	
	public void showdate() {

		// SimpleDateFormat 
		//String mydate = new SimpleDateFormat("M MM MMM MMMM").format(new Date()).toString();
		//String mydate = new SimpleDateFormat("d dd EEE EEEE").format(new Date()).toString();
		//String mydate = new SimpleDateFormat("h hh H HH").format(new Date()).toString();
		//String mydate = new SimpleDateFormat("hh:mm:ss a").format(new Date()).toString();
		String mydate = new SimpleDateFormat("MMMM dd,yyyy hh:mm a (EEE)").format(new Date()).toString();
		
		System.out.print(mydate);
		
	}
	
	
	

}
