package prackage1;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class IfDemo {
	
	
	public void readytovote() {
		
		System.out.print("Enter Birthyear: ");
		int yearnow = Integer.parseInt(new SimpleDateFormat("yyyy").format(new Date()).toString());
		
		Scanner scan1 = new Scanner(System.in);
		int mybirthyear = scan1.nextInt();
		scan1.close();
		
		int myage = yearnow - mybirthyear;
		
		// age >= 18 	"Ready to vote", 
		// age <18 		"Wait for <> years"
		// age >=100	"Happy Long Life"
		// age <=5		"too young"
		
		if(myage >= 100) {
			System.out.println("Happy Long Life");
		}else if(myage >= 18 && myage < 100){
			System.out.println("ready to vote");
		}else if(myage <18 && myage >=5) {
			int waityears = 18 - myage;
			System.out.println("wait for " + waityears + " years to vote.");
		}else {
			System.out.println("too young");
		}
		
	}
	
	
	

}
