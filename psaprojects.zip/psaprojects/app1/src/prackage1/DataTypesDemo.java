package prackage1;

import java.util.Scanner;

public class DataTypesDemo {
	
	public void testinput() {
		System.out.print("Enter your name: ");
		Scanner scanner1 = new Scanner(System.in);
		String myname = scanner1.nextLine();
		System.out.println("Good day " + myname);
	}
	
	public void provideInput(byte b, short s, int i, String st, boolean bo) {
		
		byte newb = b;
		short news = s;
		int newi = i;
		String newst = st;
		boolean newbo = bo;
		System.out.println("data collected");
		
	}
	
	
	
	
	

}
