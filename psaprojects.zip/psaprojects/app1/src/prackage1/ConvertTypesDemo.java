package prackage1;

import java.util.Scanner;

public class ConvertTypesDemo {
	
	
	public void getsum() {
		
		Scanner scan1 = new Scanner(System.in);
		System.out.print("Enter rate per hour: ");
		int rph = scan1.nextInt();
		System.out.print("Enter number of hours: ");
		int h = scan1.nextInt();
		int t = rph * h;
		
		// convert integer/float to string
		String mytotal = Integer.toString(t);
		
		// string to int
		String n1 = "23";
		int int_n1 = Integer.parseInt(n1);
		
		// int to float
		int n2 = 125;
		float float_n2 = Float.parseFloat(n1);
		
		System.out.println(n2);
		System.out.println(float_n2);
			
		//System.out.println("Total: " + t);
		
		
	}
	
	

}
