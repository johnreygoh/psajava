package prackage1;


public class Building1 {

	//properties
	String name = "CVEA";
	int storeys = 5;
	String contactnumber = "9998877"; 
	
	public void greetme() {
		System.out.println("Hello Guest!");
	}
	
	public void greetmyname(String firstname,String lastname) {
		System.out.println("Hello " + firstname + " " + lastname);
	}
	
	public void greetmyname(String firstname) {
		System.out.println("Hello " + firstname );
	}
	
	public void greetmyname() {
		String firstname = "juan";
		String lastname = "cruz";
		System.out.println("Hello " + firstname + " " + lastname);
	}

	
	

	
}
